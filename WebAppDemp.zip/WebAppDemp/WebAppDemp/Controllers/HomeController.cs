﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace WebAppDemp.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class HomeController : ControllerBase
    {
        public HomeController()
        {
        }

        [HttpGet]
        [Route("test")]
        public IActionResult Index()
        {
            return Ok("David DeGirolamo");
        }
    }
}